@echo off
setlocal EnableDelayedExpansion
title NadeLauncher - Network Setup

echo.
echo  ============================================================
echo   NadeLauncher - Network Setup
echo  ============================================================
echo.
echo  This runs once. It opens port 27015 in Windows Firewall
echo  so friends can connect to your CS2 server.
echo.
echo  Press any key to continue (requires admin rights)...
pause >/dev/null

:: Add firewall rules (TCP + UDP)
netsh advfirewall firewall show rule name="NadeLauncher CS2" >/dev/null 2>&1
if not errorlevel 1 (
    echo [OK] Firewall rule already exists.
    goto SHOW_IPS
)

echo Adding firewall rules...
netsh advfirewall firewall add rule name="NadeLauncher CS2" dir=in action=allow protocol=UDP localport=27015 >/dev/null
netsh advfirewall firewall add rule name="NadeLauncher CS2" dir=in action=allow protocol=TCP localport=27015 >/dev/null
echo [OK] Firewall rules added.

:SHOW_IPS
echo.
echo  ============================================================
echo   Your connection details
echo  ============================================================
echo.

:: Local IP
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set LAN_IP=%%a
    set LAN_IP=!LAN_IP: =!
    echo   LAN (same WiFi/network^):  connect !LAN_IP!:27015
)

:: Public IP
echo.
echo   Fetching public IP...
for /f %%a in ('powershell -NoProfile -Command "(Invoke-WebRequest -Uri 'https://api.ipify.org' -UseBasicParsing).Content"') do set PUB_IP=%%a
echo   Internet (port forwarding^): connect %PUB_IP%:27015

echo.
echo  ============================================================
echo   How friends connect
echo  ============================================================
echo.
echo   SAME NETWORK (LAN / same WiFi):
echo   -> Friend opens CS2, press tilde ~, type:
echo      connect %LAN_IP%:27015
echo.
echo   FROM THE INTERNET (Option 1 - Port Forwarding):
echo   -> Log into your router and forward port 27015 (UDP+TCP)
echo      to your local IP: %LAN_IP%
echo   -> Friend connects to: connect %PUB_IP%:27015
echo.
echo   FROM THE INTERNET (Option 2 - Tailscale, easier):
echo   -> Install Tailscale: https://tailscale.com/download
echo   -> Share your Tailscale invite: https://login.tailscale.com/admin/invite
echo   -> Friend installs Tailscale and accepts invite
echo   -> Run this bat again to see your Tailscale IP
echo   -> Friend connects to your Tailscale IP on port 27015
echo.
echo  ============================================================
echo.
pause