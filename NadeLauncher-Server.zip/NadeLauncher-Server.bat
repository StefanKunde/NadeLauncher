@echo off
setlocal EnableDelayedExpansion
title NadeLauncher CS2 Server

set HERE=%~dp0
set STEAMCMD=C:\steamcmd
set CS2DIR=C:\cs2-server
set MAXPLAYERS=12

if exist "%HERE%config.ini" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%HERE%config.ini") do (
        set _k=%%A & set _v=%%B & set _k=!_k: =!
        if /i "!_k!"=="SteamCMD"     set STEAMCMD=!_v!
        if /i "!_k!"=="CS2Server"    set CS2DIR=!_v!
        if /i "!_k!"=="MaxPlayers"   set MAXPLAYERS=!_v!

    )
)
for /l %%i in (1,1,5) do if "!CS2DIR:~-1!"==" "    set CS2DIR=!CS2DIR:~0,-1!
for /l %%i in (1,1,5) do if "!STEAMCMD:~-1!"==" "  set STEAMCMD=!STEAMCMD:~0,-1!
for /l %%i in (1,1,5) do if "!MAXPLAYERS:~-1!"==" " set MAXPLAYERS=!MAXPLAYERS:~0,-1!


set CS2EXE=%CS2DIR%\game\bin\win64\cs2.exe
set CSGO=%CS2DIR%\game\csgo
set CSS=%CSGO%\addons\counterstrikesharp
set PLUGIN=%CSS%\plugins\NadeLauncher

echo.
echo  ============================================================
echo   NadeLauncher - CS2 Practice Server
echo  ============================================================
echo.

:: ───── 1. SteamCMD ──────────────────────────────────────────────────────────
if exist "%STEAMCMD%\steamcmd.exe" goto STEAMCMD_OK
echo [1/5] Downloading SteamCMD...
if not exist "%STEAMCMD%" mkdir "%STEAMCMD%"
powershell -NoProfile -Command "Invoke-WebRequest 'https://steamcdn-a.akamaihd.net/client/installer/steamcmd.zip' -OutFile '%STEAMCMD%\steamcmd.zip'"
powershell -NoProfile -Command "Expand-Archive '%STEAMCMD%\steamcmd.zip' '%STEAMCMD%' -Force"
del "%STEAMCMD%\steamcmd.zip" >nul 2>&1
:STEAMCMD_OK
echo [OK] SteamCMD

:: ───── 2. CS2 Install + Update ──────────────────────────────────────────────
if not exist "%CS2DIR%" mkdir "%CS2DIR%"
if not exist "%CS2EXE%" (
    echo.
    echo [2/5] Installing CS2 server for the first time ^(~60 GB, 30-90 min^)...
    echo       A progress window will appear - do not close it.
    echo.
) else (
    echo [2/5] Checking for CS2 updates...
)
"%STEAMCMD%\steamcmd.exe" +login anonymous +force_install_dir "%CS2DIR%" +app_update 730 +quit
if not exist "%CS2EXE%" (
    echo.
    echo ERROR: CS2 install failed. Check internet and free disk space ^(need ~70 GB^).
    pause & exit /b 1
)
echo [OK] CS2 server up to date

:: ───── 3. Metamod + CounterStrikeSharp ──────────────────────────────────────
if exist "%CSS%\bin\win64\counterstrikesharp.dll" goto CSS_OK
echo.
echo [3/5] Installing Metamod + CounterStrikeSharp...
powershell -NoProfile -Command "Invoke-WebRequest 'https://github.com/alliedmodders/metamod-source/releases/download/2.0.0.1391/mmsource-2.0.0-git1391-windows.zip' -OutFile '%STEAMCMD%\mm.zip'"
powershell -NoProfile -Command "Expand-Archive '%STEAMCMD%\mm.zip' '%CSGO%' -Force"
del "%STEAMCMD%\mm.zip" >nul 2>&1
powershell -NoProfile -Command "Invoke-WebRequest 'https://github.com/roflmuffin/CounterStrikeSharp/releases/download/v1.0.365/counterstrikesharp-with-runtime-windows-1.0.365.zip' -OutFile '%STEAMCMD%\css.zip'"
powershell -NoProfile -Command "Expand-Archive '%STEAMCMD%\css.zip' '%CSGO%' -Force"
del "%STEAMCMD%\css.zip" >nul 2>&1
:CSS_OK
echo [OK] Metamod + CounterStrikeSharp

:: ───── 4. Patch gameinfo.gi ─────────────────────────────────────────────────
findstr /C:"addons/metamod" "%CSGO%\gameinfo.gi" >nul 2>&1
if not errorlevel 1 goto GAMEINFO_OK
powershell -NoProfile -Command "$f='%CSGO%\gameinfo.gi'; $t=[char]9; $m=$t+$t+$t+'Game'+$t+'csgo/addons/metamod'; $ls=[System.Collections.Generic.List[string]]([System.IO.File]::ReadAllLines($f)); $i=0; while($i -lt $ls.Count -and $ls[$i].TrimEnd() -ne $t+$t+$t+'Game'+$t+'csgo'){$i++}; if($i -lt $ls.Count){$ls.Insert($i,$m);[System.IO.File]::WriteAllLines($f,$ls)}"
:GAMEINFO_OK
echo [OK] gameinfo.gi

:: ───── 5. Configs + Plugin ──────────────────────────────────────────────────
if not exist "%CSGO%\cfg" mkdir "%CSGO%\cfg"
if not exist "%CSS%\configs\plugins\NadeLauncher" mkdir "%CSS%\configs\plugins\NadeLauncher"
if not exist "%PLUGIN%" mkdir "%PLUGIN%"

set NL_CSGO=%CSGO%
set NL_CSS=%CSS%
set NL_MAXPLAYERS=!MAXPLAYERS!
powershell -NoProfile -EncodedCommand JABjAHMAZwBvACAAPQAgACQAZQBuAHYAOgBOAEwAXwBDAFMARwBPAAoAJABjAHMAcwAgAD0AIAAkAGUAbgB2ADoATgBMAF8AQwBTAFMACgAkAG0AYQB4AFAAbABhAHkAZQByAHMAIAA9ACAAJABlAG4AdgA6AE4ATABfAE0AQQBYAFAATABBAFkARQBSAFMACgAKACMAIABzAGUAcgB2AGUAcgAuAGMAZgBnAAoAJABzAGUAcgB2AGUAcgBDAGYAZwBQAGEAdABoACAAPQAgAEoAbwBpAG4ALQBQAGEAdABoACAAJABjAHMAZwBvACAAIgBjAGYAZwBcAHMAZQByAHYAZQByAC4AYwBmAGcAIgAKAGkAZgAgACgALQBuAG8AdAAgACgAVABlAHMAdAAtAFAAYQB0AGgAIAAkAHMAZQByAHYAZQByAEMAZgBnAFAAYQB0AGgAKQApACAAewAKACAAIAAgACAAJABsAGkAbgBlAHMAIAA9ACAAQAAoAAoAIAAgACAAIAAgACAAIAAgACIAcwB2AF8AYwBoAGUAYQB0AHMAIAAxACIALAAKACAAIAAgACAAIAAgACAAIAAiAHMAdgBfAG0AYQB4AHAAbABhAHkAZQByAHMAIAAkAG0AYQB4AFAAbABhAHkAZQByAHMAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAYgBvAHQAXwBrAGkAYwBrACIALAAKACAAIAAgACAAIAAgACAAIAAiAGIAbwB0AF8AcQB1AG8AdABhACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwBkAG8AXwB3AGEAcgBtAHUAcABfAHAAZQByAGkAbwBkACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwB3AGEAcgBtAHUAcAB0AGkAbQBlACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwB3AGEAcgBtAHUAcABfAHAAYQB1AHMAZQB0AGkAbQBlAHIAIAAwACIALAAKACAAIAAgACAAIAAgACAAIAAiAG0AcABfAHcAYQByAG0AdQBwAF8AZQBuAGQAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AZgByAGUAZQB6AGUAdABpAG0AZQAgADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AcgBvAHUAbgBkAHQAaQBtAGUAIAA2ADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AcgBvAHUAbgBkAHQAaQBtAGUAXwBkAGUAZgB1AHMAZQAgADYAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwByAG8AdQBuAGQAXwByAGUAcwB0AGEAcgB0AF8AZABlAGwAYQB5ACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwBsAGkAbQBpAHQAdABlAGEAbQBzACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwBhAHUAdABvAHQAZQBhAG0AYgBhAGwAYQBuAGMAZQAgADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AbQBhAHgAbQBvAG4AZQB5ACAANgAwADAAMAAwACIALAAKACAAIAAgACAAIAAgACAAIAAiAG0AcABfAHMAdABhAHIAdABtAG8AbgBlAHkAIAA2ADAAMAAwADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AYgB1AHkAXwBhAG4AeQB3AGgAZQByAGUAIAAxACIALAAKACAAIAAgACAAIAAgACAAIAAiAG0AcABfAGIAdQB5AHQAaQBtAGUAIAA5ADkAOQA5ACIALAAKACAAIAAgACAAIAAgACAAIAAiAG0AcABfAGYAcgBpAGUAbgBkAGwAeQBmAGkAcgBlACAAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBtAHAAXwBhAHUAdABvAGsAaQBjAGsAIAAwACIALAAKACAAIAAgACAAIAAgACAAIAAiAG0AcABfAGQAYQBtAGEAZwBlAF8AcwBjAGEAbABlAF8AYwB0AF8AYgBvAGQAeQAgADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AZABhAG0AYQBnAGUAXwBzAGMAYQBsAGUAXwB0AF8AYgBvAGQAeQAgADAAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AcgBlAHMAcABhAHcAbgBfAG8AbgBfAGQAZQBhAHQAaABfAGMAdAAgADEAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAbQBwAF8AcgBlAHMAcABhAHcAbgBfAG8AbgBfAGQAZQBhAHQAaABfAHQAIAAxACIALAAKACAAIAAgACAAIAAgACAAIAAiAHMAdgBfAGYAYQBsAGwAZABhAG0AYQBnAGUAXwBzAGMAYQBsAGUAIAAwACIALAAKACAAIAAgACAAIAAgACAAIAAiAHMAdgBfAHIAZQBnAGUAbgBlAHIAYQB0AGkAbwBuAF8AZgBvAHIAYwBlAF8AbwBuACAAMQAiACwACgAgACAAIAAgACAAIAAgACAAIgBzAHYAXwBpAG4AZgBpAG4AaQB0AGUAXwBhAG0AbQBvACAAMQAiACwACgAgACAAIAAgACAAIAAgACAAIgBhAG0AbQBvAF8AZwByAGUAbgBhAGQAZQBfAGwAaQBtAGkAdABfAHQAbwB0AGEAbAAgADUAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAcwB2AF8AZwByAGUAbgBhAGQAZQBfAHQAcgBhAGoAZQBjAHQAbwByAHkAIAAxACIALAAKACAAIAAgACAAIAAgACAAIAAiAHMAdgBfAGcAcgBlAG4AYQBkAGUAXwB0AHIAYQBqAGUAYwB0AG8AcgB5AF8AdABpAG0AZQAgADEAMAAiACwACgAgACAAIAAgACAAIAAgACAAIgBzAHYAXwBnAHIAZQBuAGEAZABlAF8AdAByAGEAagBlAGMAdABvAHIAeQBfAHAAcgBhAGMAXwBwAGkAcAByAGUAdgBpAGUAdwAgADEAIgAsAAoAIAAgACAAIAAgACAAIAAgACIAcwB2AF8AcwBoAG8AdwBpAG0AcABhAGMAdABzACAAMQAiACwACgAgACAAIAAgACAAIAAgACAAIgBzAHYAXwBzAGgAbwB3AGkAbQBwAGEAYwB0AHMAXwB0AGkAbQBlACAAMQAwACIACgAgACAAIAAgACkACgAgACAAIAAgAFsAUwB5AHMAdABlAG0ALgBJAE8ALgBGAGkAbABlAF0AOgA6AFcAcgBpAHQAZQBBAGwAbABMAGkAbgBlAHMAKAAkAHMAZQByAHYAZQByAEMAZgBnAFAAYQB0AGgALAAgACQAbABpAG4AZQBzACwAIABbAFMAeQBzAHQAZQBtAC4AVABlAHgAdAAuAEUAbgBjAG8AZABpAG4AZwBdADoAOgBBAFMAQwBJAEkAKQAKACAAIAAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAWwBPAEsAXQAgAHMAZQByAHYAZQByAC4AYwBmAGcAIAB3AHIAaQB0AHQAZQBuACIACgB9ACAAZQBsAHMAZQAgAHsACgAgACAAIAAgAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAiAFsATwBLAF0AIABzAGUAcgB2AGUAcgAuAGMAZgBnACAAYQBsAHIAZQBhAGQAeQAgAGUAeABpAHMAdABzACIACgB9AAoACgAjACAATgBhAGQAZQBMAGEAdQBuAGMAaABlAHIALgBqAHMAbwBuAAoAJABuAGwAQwBmAGcARABpAHIAIAA9ACAASgBvAGkAbgAtAFAAYQB0AGgAIAAoAEoAbwBpAG4ALQBQAGEAdABoACAAJABjAHMAcwAgACIAYwBvAG4AZgBpAGcAcwBcAHAAbAB1AGcAaQBuAHMAIgApACAAIgBOAGEAZABlAEwAYQB1AG4AYwBoAGUAcgAiAAoAaQBmACAAKAAtAG4AbwB0ACAAKABUAGUAcwB0AC0AUABhAHQAaAAgACQAbgBsAEMAZgBnAEQAaQByACkAKQAgAHsAIABOAGUAdwAtAEkAdABlAG0AIAAtAEkAdABlAG0AVAB5AHAAZQAgAEQAaQByAGUAYwB0AG8AcgB5ACAALQBQAGEAdABoACAAJABuAGwAQwBmAGcARABpAHIAIAB8ACAATwB1AHQALQBOAHUAbABsACAAfQAKACQAbgBsAEMAZgBnAFAAYQB0AGgAIAA9ACAASgBvAGkAbgAtAFAAYQB0AGgAIAAkAG4AbABDAGYAZwBEAGkAcgAgACIATgBhAGQAZQBMAGEAdQBuAGMAaABlAHIALgBqAHMAbwBuACIACgBpAGYAIAAoAC0AbgBvAHQAIAAoAFQAZQBzAHQALQBQAGEAdABoACAAJABuAGwAQwBmAGcAUABhAHQAaAApACkAIAB7AAoAIAAgACAAIAAkAGoAcwBvAG4AIAA9ACAAJwB7AAoAIAAgACIAQwBvAG4AZgBpAGcAVgBlAHIAcwBpAG8AbgAiADoAIAAxACwACgAgACAAIgBDAGgAYQB0AFAAcgBlAGYAaQB4ACIAOgAgACIAIABcAHUAMAAwADAANABbAE4AYQBkAGUATABhAHUAbgBjAGgAZQByAF0AXAB1ADAAMAAwADEAIAAiACwACgAgACAAIgBNAGUAbgB1AFAAYQBnAGUAUwBpAHoAZQAiADoAIAA1ACwACgAgACAAIgBPAHcAbgBlAHIAUwB0AGUAYQBtAEkAZABzACIAOgAgAFsAXQAsAAoAIAAgACIAQQB1AHQAbwBBAGMAdABpAHYAYQB0AGUAIgA6ACAAdAByAHUAZQAKAH0AJwAKACAAIAAgACAAWwBTAHkAcwB0AGUAbQAuAEkATwAuAEYAaQBsAGUAXQA6ADoAVwByAGkAdABlAEEAbABsAFQAZQB4AHQAKAAkAG4AbABDAGYAZwBQAGEAdABoACwAIAAkAGoAcwBvAG4ALAAgAFsAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4ARQBuAGMAbwBkAGkAbgBnAF0AOgA6AFUAVABGADgAKQAKACAAIAAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAWwBPAEsAXQAgAE4AYQBkAGUATABhAHUAbgBjAGgAZQByAC4AagBzAG8AbgAgAHcAcgBpAHQAdABlAG4AIgAKAH0AIABlAGwAcwBlACAAewAKACAAIAAgACAAVwByAGkAdABlAC0ASABvAHMAdAAgACIAWwBPAEsAXQAgAE4AYQBkAGUATABhAHUAbgBjAGgAZQByAC4AagBzAG8AbgAgAGEAbAByAGUAYQBkAHkAIABlAHgAaQBzAHQAcwAiAAoAfQAKAA==
echo [OK] Configs
if exist "%HERE%plugin\NadeLauncher.dll" (
    xcopy /E /Y /Q "%HERE%plugin\*" "%PLUGIN%\" >nul 2>&1
    echo [OK] Plugin installed/updated
) else (
    echo [WARN] plugin\ folder not found - skipping plugin install
)

:: ───── Launch ────────────────────────────────────────────────────────────────
copy /Y "%STEAMCMD%\steamclient.dll"   "%CS2DIR%\game\bin\win64\" >nul 2>&1
copy /Y "%STEAMCMD%\steamclient64.dll" "%CS2DIR%\game\bin\win64\" >nul 2>&1
copy /Y "%STEAMCMD%\steam.dll"         "%CS2DIR%\game\bin\win64\" >nul 2>&1

echo.
echo  ============================================================
echo   Server starting on port 27015  ^(max players: !MAXPLAYERS!^)
echo.
echo   This PC:         connect localhost:27015
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set _ip=%%a
    set _ip=!_ip: =!
    echo   Same network:    connect !_ip!:27015
)
echo   Internet:        run setup-network.bat to see your public IP
echo  ============================================================
echo.

"%CS2EXE%" -dedicated -console -port 27015 +game_type 0 +game_mode 0 +map de_dust2 +sv_cheats 1 +sv_maxplayers !MAXPLAYERS! +exec server.cfg
