﻿NadeLauncher - CS2 Practice Server
===================================

REQUIREMENTS
------------
- Windows 10 or Windows 11 (64-bit)
- ~70 GB free disk space (CS2 server is ~60 GB)
- Internet connection (for first-time setup)
- CS2 installed on Steam (to connect as a client)

No Python, no Docker, no additional software needed.
The bat file downloads and installs everything automatically.


HOW TO USE
----------
1. Extract this ZIP anywhere (e.g. Desktop or C:\NadeLauncherServer)
2. Double-click NadeLauncher-Server.bat
3. First run: downloads CS2 server, Metamod, CounterStrikeSharp (~60 GB, 30-90 min)
4. Server starts automatically when done
5. Open CS2, press ~ (tilde) to open console, type:
     connect localhost:27015


EVERY NEXT TIME
---------------
Just double-click NadeLauncher-Server.bat again.
It checks for CS2 updates and starts the server (~30 sec if already up to date).


CHANGE INSTALL LOCATION
-----------------------
Open config.ini and edit the paths before the first run:

  SteamCMD=C:\steamcmd       <- where SteamCMD gets installed (~50 MB)
  CS2Server=C:\cs2-server    <- where the CS2 server gets installed (~60 GB)

Example to install on D:\ instead:
  CS2Server=D:\cs2-server


WHAT GETS INSTALLED
-------------------
  C:\steamcmd\             SteamCMD (Steam download tool)
  C:\cs2-server\           CS2 Dedicated Server + Metamod + CounterStrikeSharp + Plugin

Nothing is installed to Program Files or the Windows registry.
Your own CS2 game installation is not affected.


SHARING LINEUPS
---------------

--- EXPORT (send your lineups to someone) ---

1. Double-click export-lineups.bat
2. A file named  nadelauncher-lineups-YYYY-MM-DD.zip  is created
   in the same folder as the bat
3. Send that ZIP to your friend

--- IMPORT (receive lineups from someone) ---

Option A - Drag and drop:
  Drag the received ZIP file directly onto import-lineups.bat

Option B - Manual:
  1. Double-click import-lineups.bat
  2. Paste the full path to the ZIP file and press Enter

After import the script tells you how many lineups were added
and how many were skipped (because you already had them).
Restart the CS2 server to load the new lineups in-game.


PLAYING WITH FRIENDS
--------------------

There are three ways to let friends join your server:

--- OPTION 1: Same network (LAN) ---
If you and your friends are on the same Wi-Fi or LAN:
  1. Run setup-network.bat (once) to open the firewall
  2. Tell your friend your local IP (shown when server starts)
  3. Friend connects with:  connect 192.168.x.x:27015

--- OPTION 2: Internet - Port Forwarding ---
  1. Log in to your router (usually http://192.168.1.1)
  2. Forward port 27015 (UDP + TCP) to your PC's local IP
  3. Run setup-network.bat to see your public IP
  4. Friend connects with:  connect YOUR.PUBLIC.IP:27015
  Note: Your public IP may change. Some ISPs block port forwarding.

--- OPTION 3: Tailscale (easiest, no router changes) ---
  1. You and your friends all install Tailscale (free): https://tailscale.com
  2. Everyone joins the same Tailscale network
  3. Run setup-network.bat to see your Tailscale IP (100.x.x.x)
  4. Friend connects with:  connect 100.x.x.x:27015
  No port forwarding, works through any firewall.

Run setup-network.bat to automate the firewall setup and show all IPs.


WHAT IS NADELAUNCHER
--------------------
A CS2 plugin for practicing grenade lineups.
- Save grenade positions with !save
- Browse lineups per map with !lineups
- Train lineups with !train


TROUBLESHOOTING
---------------
"CS2 install failed"
  -> Make sure you have ~70 GB free on C:\ (or wherever config.ini points)
  -> Check your internet connection and run the bat again
  -> If it fails halfway, just run the bat again - it resumes where it left off

"connect localhost:27015" doesn't work
  -> Wait ~30 seconds after the server window opens for it to fully load
  -> Make sure Windows Firewall allows the server (click "Allow" if prompted)

Server window closes immediately
  -> Run NadeLauncher-Server.bat as Administrator (right-click -> Run as administrator)